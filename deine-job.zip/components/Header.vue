<template>
    <div class="z-50 pt-1.5 fixed w-full rounded-br-xl rounded-bl-xl bg-gradient-to-r from-green-600 to-blue-400">
        <header class="bg-white w-full rounded-br-xl rounded-bl-xl h-16 shadow-lg">
            <div class="navbar flex justify-end px-3.5 h-full items-center">
                <NuxtLink to="/">Login</NuxtLink>
            </div>
        </header>
    </div>
</template>