<template>
    <div>
        <footer class="fixed z-50 bottom-0 w-full bg-white rounded-tr-xl rounded-tl-xl h-28 shadow">
            <div class="navbar flex justify-center px-3.5 h-full items-center">
                <NuxtLink to="/" class="bg-gradient-to-r from-green-600 to-blue-400 text-white text-sm py-3.5 text-center rounded-xl max-w-80 w-full">Kostenlos Registrieren</NuxtLink>
            </div>
        </footer>
    </div>
</template>